import Main from "./Main.js";

function App() {
  return (
    <>
      <Main />
    </>
  );
}

export default App;
